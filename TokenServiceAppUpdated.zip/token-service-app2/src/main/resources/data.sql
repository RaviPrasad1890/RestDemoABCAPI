insert into CUSTOMER
values(10001, 'CustomerOne', true);
insert into CUSTOMER
values(10002, 'CustomerTwo', false);
insert into CUSTOMER
values(10003, 'CustomerThree', false);

insert into COUNTER
values(1,true,null);
insert into COUNTER
values(2,true,null);
insert into COUNTER
values(3,false,null);
insert into COUNTER
values(4,false,null);